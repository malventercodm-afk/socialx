# SocialX

Working SocialX starter with real email/username + password authentication.

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Set a strong `JWT_SECRET` environment variable.
4. Run `npm start`.
5. Open `http://localhost:3000`.

User accounts are stored in `data/users.json` and passwords are hashed with bcryptjs. For a public production launch, move users to a managed database and configure HTTPS, backups, rate limiting, email verification and password reset.

## Deploy
This can be deployed to any Node.js host that supports a persistent writable disk. If the host uses ephemeral storage, replace `data/users.json` with a database before launch.
