const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-before-production';
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '[]');

const readUsers = () => JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
const writeUsers = users => fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

function auth(req, res, next) {
  try {
    const token = req.cookies.socialx_token;
    if (!token) return res.status(401).json({ error: 'Not logged in' });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = readUsers().find(u => u.id === payload.id);
    if (!user) return res.status(401).json({ error: 'Account not found' });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: 'Session expired' }); }
}

app.post('/api/signup', async (req, res) => {
  const name = String(req.body.name || '').trim();
  const username = String(req.body.username || '').trim().toLowerCase();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!name || !username || !email || password.length < 8) return res.status(400).json({ error: 'Enter all fields. Password must be at least 8 characters.' });
  if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Username: 3–20 letters, numbers or underscores.' });
  const users = readUsers();
  if (users.some(u => u.email === email)) return res.status(409).json({ error: 'Email already registered.' });
  if (users.some(u => u.username === username)) return res.status(409).json({ error: 'Username already taken.' });
  const user = { id: cryptoRandomId(), name, username, email, passwordHash: await bcrypt.hash(password, 12), createdAt: new Date().toISOString() };
  users.push(user); writeUsers(users); setSession(res, user);
  res.json({ user: publicUser(user) });
});

app.post('/api/login', async (req, res) => {
  const login = String(req.body.login || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = readUsers().find(u => u.email === login || u.username === login);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: 'Incorrect login details.' });
  setSession(res, user); res.json({ user: publicUser(user) });
});

app.post('/api/logout', (req, res) => { res.clearCookie('socialx_token', cookieOptions()); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));

function setSession(res, user) {
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('socialx_token', token, cookieOptions());
}
function cookieOptions() { return { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7*24*60*60*1000 }; }
function publicUser(u) { return { id: u.id, name: u.name, username: u.username, email: u.email, createdAt: u.createdAt }; }
function cryptoRandomId() { return require('crypto').randomUUID(); }

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`SocialX running on port ${PORT}`));
